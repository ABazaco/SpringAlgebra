package com.example.forumalex.service.dto;

public class QuestionDTO {
}
