package com.example.forumalex;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ForumAlexApplication {

    public static void main(String[] args) {
        SpringApplication.run(ForumAlexApplication.class, args);
    }

}
